import {env} from 'cloudflare:workers';
import {identity,privateData,sameOrigin,privateHeaders} from '../../../lib/catalog';
import {clientKey,normalize,discountPercent} from '../../../lib/access';
import {digest} from '../../../lib/sessions';
const headers={...privateHeaders,'Referrer-Policy':'no-referrer'};
type Link={client_key:string;token:string;enabled:number};
export async function GET(request:Request){
 const me=await identity();if(!me?.admin)return Response.json({error:'Acceso denegado'},{status:403,headers});
 const base=await privateData();const q=normalize(new URL(request.url).searchParams.get('q')||'');
 const matches=base.clients.filter((c:any)=>!q||normalize([c.rs,c.rut,c.cod,c.vend].join(' ')).includes(q));
 const links=await env.DB!.prepare('SELECT client_key,token,enabled FROM client_links').all<Link>();const byKey=new Map(links.results.map(r=>[r.client_key,r]));const origin=new URL(request.url).origin;
 return Response.json({total:matches.length,clients:matches.slice(0,50).map((c:any)=>{const key=clientKey(c);const link=byKey.get(key);return {key,rs:c.rs,rut:c.rut,cod:c.cod,vend:c.vend,wa:c.wa||'',mail:c.mail||'',discount:discountPercent(c.dcto),active:link?.enabled===1,url:link?.enabled===1?origin+'/c/'+link.token:null};})},{headers});
}
export async function POST(request:Request){
 const me=await identity();if(!me?.admin)return Response.json({error:'Acceso denegado'},{status:403,headers});
 if(!sameOrigin(request))return Response.json({error:'Origen no permitido'},{status:403,headers});
 try{
  const body=await request.json() as {action:string;key:string};
  const base=await privateData();const matches=base.clients.filter((c:any)=>clientKey(c)===body.key);if(matches.length!==1)throw new Error('El cliente no existe o su código no es único.');
  if(body.action==='revoke'){await env.DB!.prepare('UPDATE client_links SET enabled=0 WHERE client_key=?').bind(body.key).run();return Response.json({message:'Enlace revocado. Dejó de permitir acceso al catálogo.'},{headers});}
  if(body.action!=='create')throw new Error('Acción no válida.');
  let link=await env.DB!.prepare('SELECT client_key,token,enabled FROM client_links WHERE client_key=?').bind(body.key).first<Link>();
  if(link?.enabled!==1){const token=Array.from(crypto.getRandomValues(new Uint8Array(32)),b=>b.toString(16).padStart(2,'0')).join('');await env.DB!.prepare('INSERT INTO client_links(client_key,token_hash,token,enabled,created_at) VALUES(?,?,?,1,?) ON CONFLICT(client_key) DO UPDATE SET token_hash=excluded.token_hash,token=excluded.token,enabled=1,created_at=excluded.created_at').bind(body.key,await digest(token),token,Date.now()).run();link={client_key:body.key,token,enabled:1};}
  return Response.json({url:new URL(request.url).origin+'/c/'+link.token,message:'Enlace permanente listo. Compártelo solamente con este cliente.'},{headers});
 }catch(error){return Response.json({error:error instanceof Error?error.message:'No se pudo generar el enlace'},{status:400,headers});}
}
