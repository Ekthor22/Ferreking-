import {privateData} from '../../../lib/catalog';
export async function GET(){
 try{await privateData();return Response.json({ready:true},{headers:{'Cache-Control':'no-store'}});}
 catch{return Response.json({ready:false},{status:503,headers:{'Cache-Control':'no-store'}});}
}
