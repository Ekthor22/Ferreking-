import { env } from 'cloudflare:workers';
import { identity, privateData, parseMaster, sameOrigin, privateHeaders } from '../../../lib/catalog';
import {seedRevision} from '../../../lib/seed-revision';
export async function POST(request: Request) {
 const me=await identity();
 if(!me?.admin)return Response.json({error:'Acceso denegado'},{status:403,headers:privateHeaders});
 if(!sameOrigin(request))return Response.json({error:'Origen no permitido'},{status:403});
 try {
  const form=await request.formData(); const action=form.get('action');
  if(action==='upload') {
   const file=form.get('file');
   if(!(file instanceof File)||file.size>20000000)throw new Error('Selecciona un maestro HTML de hasta 20 MB.');
   const data=parseMaster(await file.text());
   // Productos y fotografías siempre vienen del catálogo público actualizado.
   delete data.products; delete data.images;
   await env.BUCKET!.put('private/catalog.json',JSON.stringify(data),{httpMetadata:{contentType:'application/json'},customMetadata:{seed_revision:seedRevision}});
   return Response.json({message:`Cartera actualizada: ${data.clients.length} clientes y ${data.users.length} usuarios.`},{headers:privateHeaders});
  }
  throw new Error('Acción no válida.');
 }catch(error){return Response.json({error:error instanceof Error?error.message:'No se pudo guardar'},{status:400,headers:privateHeaders});}
}
