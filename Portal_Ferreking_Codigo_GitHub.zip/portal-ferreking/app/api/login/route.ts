import {env} from 'cloudflare:workers';
import {digest,equal} from '../../../lib/sessions';
import {privateData,sameOrigin,privateHeaders} from '../../../lib/catalog';
export async function POST(request:Request){
 if(!sameOrigin(request))return Response.json({error:'Origen no permitido'},{status:403});
 const ip=request.headers.get('cf-connecting-ip')||'unknown';
 let input:any;try{input=await request.json();}catch{return Response.json({error:'Solicitud no válida'},{status:400});}
 const username=String(input.username||'').trim().toLowerCase();const pin=String(input.pin||'').trim();
 if(username.length>64||pin.length>64)return Response.json({error:'Datos no válidos'},{status:400});
 const keys=[await digest('ip:'+ip),await digest('user:'+username)];const now=Date.now();
 for(const key of keys){
  // Incremento atómico y compartido entre dispositivos. Las cuentas no existen en el cliente.
  const rate=await env.DB!.prepare('INSERT INTO attempts (key,count,reset_at) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET count=CASE WHEN reset_at<? THEN 1 ELSE count+1 END, reset_at=CASE WHEN reset_at<? THEN excluded.reset_at ELSE reset_at END RETURNING count').bind(key,now+900000,now,now).first<{count:number}>();
  if((rate?.count||0)>(key===keys[0]?40:8))return Response.json({error:'Demasiados intentos. Espera 15 minutos y vuelve a intentar.'},{status:429,headers:{...privateHeaders,'Retry-After':'900'}});
 }
 const data=await privateData();const seller=data.users.find((u:any)=>String(u.u).toLowerCase()===username);
 const candidate=await digest('FK1:'+username+':'+pin);
 if(!seller||!equal(candidate,seller.h||'0'.repeat(64)))return Response.json({error:'Usuario o PIN incorrecto.'},{status:401,headers:privateHeaders});
 await env.DB!.batch(keys.map(key=>env.DB!.prepare('DELETE FROM attempts WHERE key=?').bind(key)));
 const bytes=crypto.getRandomValues(new Uint8Array(32));const token=Array.from(bytes,v=>v.toString(16).padStart(2,'0')).join('');
 await env.DB!.prepare('INSERT INTO sessions (token_hash,seller,pin_hash,expires) VALUES (?,?,?,?)').bind(await digest(token),seller.u,seller.h,now+86400000).run();
 return Response.json({ok:true},{headers:{...privateHeaders,'Set-Cookie':`fk_session=${token}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=86400`}});
}
