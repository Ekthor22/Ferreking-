import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Ferreking · Vendedores",
  description: "Catálogo privado, cartera y cotizaciones de Ferreking.",
  manifest: "/manifest.webmanifest",
  icons: {
    icon: "/icons/icon-192.png",
    shortcut: "/icons/icon-192.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es-CL">
      <body className="antialiased">{children}</body>
    </html>
  );
}
