import {redirect} from 'next/navigation';
import {identity,privateData} from '../lib/catalog';
import Register from './register';
export const dynamic='force-dynamic';
export default async function Home(){
 const me=await identity();if(!me)redirect('/acceso');const data=await privateData();const seller=data.users.find((u:any)=>u.u===me.sellerCode);
 return <main className="shell"><Register/><div className="brand">FERRE<span>KING</span></div><p className="eyebrow">VENTAS · ACCESO PRIVADO</p><h1>Tu catálogo.<br/>Tu cartera.</h1><p className="lead">Hola, {me.displayName}. Consulta los productos, elige un cliente y prepara su cotización.</p><div className="card"><p className="label">SESIÓN ACTIVA</p><strong>{me.displayName}</strong><p>Perfil: {me.admin?'Administrador':seller?.sv||seller?.n}</p><a className="button" href="/catalogo">Abrir catálogo y cartera →</a>{me.admin&&<a className="secondary" href="/administracion">Cartera y enlaces para clientes</a>}</div><div className="guide"><h2>Instálalo una vez</h2><p>Android: abre este enlace en Chrome y selecciona «Instalar aplicación» en el menú ⋮. Windows: usa la opción de instalación de Chrome o Edge.</p><p>Los precios y productos se recuperan de tu catálogo publicado en GitHub cada vez que abres el catálogo. La cartera se administra aquí de forma privada.</p><p>Se requiere conexión para consultar la cartera. Las cotizaciones se conservan en este dispositivo; puedes exportarlas desde el historial.</p></div><a className="muted" href="/salir">Cerrar sesión</a></main>;
}
