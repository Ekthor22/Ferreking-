import {customerForToken,customerHeaders} from '../../../../lib/customer';
export async function GET(request:Request,context:{params:Promise<{token:string}>}){
 const {token}=await context.params;const allowed=await customerForToken(token);
 if(!allowed)return new Response('Enlace no disponible',{status:404,headers:customerHeaders});
 return Response.json({id:'/c/'+token,name:'Ferreking · '+allowed.client.rs,short_name:'Ferreking',description:'Catálogo actualizado con tus condiciones comerciales',lang:'es-CL',start_url:'/c/'+token,scope:'/',display:'standalone',background_color:'#111010',theme_color:'#111010',icons:[{src:'/icons/icon-192.png',sizes:'192x192',type:'image/png'},{src:'/icons/icon-512.png',sizes:'512x512',type:'image/png'},{src:'/icons/icon-maskable-512.png',sizes:'512x512',type:'image/png',purpose:'maskable'}]},{headers:{...customerHeaders,'Content-Type':'application/manifest+json'}});
}
