import {customerForToken,customerData,customerHeaders} from '../../../lib/customer';
import {publicData} from '../../../lib/catalog';
import template from '../../../lib/customer-template';
export async function GET(request:Request,context:{params:Promise<{token:string}>}){
 const {token}=await context.params;
 const allowed=await customerForToken(token);
 if(!allowed)return new Response('Este enlace no está disponible. Solicita un enlace vigente a tu vendedor.',{status:404,headers:customerHeaders});
 try{
  const pub=await publicData();const data=customerData(allowed.base,pub,allowed.client);
  const html=template.replace('__FK_CUSTOMER_DATA__',JSON.stringify(data).replace(/</g,'\\u003c')).replace('__FK_CUSTOMER_MANIFEST__','/c/'+token+'/manifest.webmanifest');
  return new Response(html,{headers:{...customerHeaders,'Content-Type':'text/html; charset=utf-8'}});
 }catch{return new Response('No se pudo cargar la lista vigente. Vuelve a intentar en unos minutos.',{status:503,headers:customerHeaders});}
}
