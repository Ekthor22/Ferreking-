import {cookies} from 'next/headers';
import {env} from 'cloudflare:workers';
import {digest} from '../../lib/sessions';
import {privateHeaders} from '../../lib/catalog';
export async function GET(request:Request){const token=(await cookies()).get('fk_session')?.value;if(token)await env.DB!.prepare('DELETE FROM sessions WHERE token_hash=?').bind(await digest(token)).run();return new Response(null,{status:303,headers:{...privateHeaders,Location:new URL('/acceso',request.url).toString(),'Set-Cookie':'fk_session=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0'}});}
