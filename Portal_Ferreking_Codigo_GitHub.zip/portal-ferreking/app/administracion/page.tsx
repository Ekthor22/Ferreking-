import {redirect} from 'next/navigation';
import {identity,privateData} from '../../lib/catalog';
import {clientsForUser} from '../../lib/access';
import Admin from './ui';
export const dynamic='force-dynamic';
export default async function Page(){const me=await identity();if(!me)redirect('/acceso');if(!me.admin)return <main className="shell"><h1>Acceso denegado</h1><a href="/">Volver</a></main>;const data=await privateData();return <Admin sellers={data.users.filter((u:any)=>u.r!=='admin').map((u:any)=>({u:u.u,n:u.n,sv:u.sv||u.n,all:!!u.all,count:clientsForUser(data.clients,u).length}))} count={data.clients.length}/>;}
