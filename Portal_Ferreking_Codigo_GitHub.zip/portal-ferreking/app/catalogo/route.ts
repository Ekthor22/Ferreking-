import { identity, privateData, publicData, privateHeaders } from '../../lib/catalog';
import { clientsForUser } from '../../lib/access';
import template from '../../lib/catalog-template';
export async function GET(request: Request) {
 const me = await identity();
 if (!me) return Response.redirect(new URL('/acceso', request.url));
 const base = await privateData();
 const seller = me.admin ? base.users.find((u:any)=>u.r==='admin') : base.users.find((u:any)=>u.u===me.sellerCode && u.r!=='admin');
 if (!seller) return new Response('Acceso pendiente. El administrador debe asignar tu correo a un vendedor.', {status:403,headers:privateHeaders});
 try {
  const pub = await publicData();
  const data = {...base,products:pub.products,images:pub.images,ver:pub.ver,clients:clientsForUser(base.clients,seller),users:[{...seller,h:undefined}],pub:false,sync:{url:'',key:''},sessionUser:seller.u,sessionKey:me.userId};
  const html = template.replace('__FK_SERVER_DATA__', JSON.stringify(data).replace(/</g,'\\u003c'));
  return new Response(html,{headers:{...privateHeaders,'Content-Type':'text/html; charset=utf-8'}});
 } catch {
  return new Response('No se pudo cargar la lista publicada. Vuelve a intentar en unos minutos.',{status:503,headers:privateHeaders});
 }
}
