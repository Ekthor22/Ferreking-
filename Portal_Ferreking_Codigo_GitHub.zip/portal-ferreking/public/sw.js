self.addEventListener('install',()=>self.skipWaiting());
self.addEventListener('activate',event=>event.waitUntil(self.clients.claim()));
self.addEventListener('fetch',event=>{
 const request=event.request;
 if(request.method!=='GET')return;
 if(request.mode==='navigate')event.respondWith(fetch(request,{cache:'no-store'}).catch(()=>new Response('<html lang="es"><meta name="viewport" content="width=device-width"><body style="font-family:Arial;padding:30px"><h1>Ferreking</h1><p>Conéctate a internet para acceder a tu cartera y cargar el catálogo actualizado.</p><button onclick="location.reload()">Volver a intentar</button></body></html>',{headers:{'Content-Type':'text/html;charset=utf-8','Cache-Control':'no-store'}})));
});
