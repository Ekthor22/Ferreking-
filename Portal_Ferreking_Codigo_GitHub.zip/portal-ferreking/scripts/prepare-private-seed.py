"""Preparar datos privados localmente; el resultado está excluido de Git."""
from pathlib import Path
import argparse,json,re,hashlib
parser=argparse.ArgumentParser()
parser.add_argument('master_html',type=Path)
args=parser.parse_args()
html=args.master_html.read_text(encoding='utf-8')
match=re.search(r'<script\s+id="fk-data"\s+type="application/json">(.*?)</script>',html,re.S)
if not match:raise SystemExit('No se reconocen los datos del maestro.')
data=json.loads(match.group(1))
if data.get('pub') or not data.get('users'):raise SystemExit('Usa el maestro privado con usuarios y cartera.')
data.pop('products',None);data.pop('images',None);data['sync']={'url':'','key':''}
target=Path(__file__).resolve().parent.parent/'lib/seed-private.json'
raw=json.dumps(data,ensure_ascii=False)
target.write_text(raw,encoding='utf-8')
(target.parent/'seed-revision.ts').write_text('export const seedRevision='+json.dumps(hashlib.sha256(raw.encode()).hexdigest()[:24])+';\n',encoding='utf-8')
print('Datos privados preparados localmente. No publiques este archivo ni lo incluyas en GitHub.')
