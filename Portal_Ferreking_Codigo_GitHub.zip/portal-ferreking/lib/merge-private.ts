import {clientKey} from './access';
export function completePrivateData(seed:any,current:any){
 if(!current)return structuredClone(seed);
 const clients=new Map<string,any>(seed.clients.map((c:any)=>[clientKey(c),{...c}]));
 for(const c of current.clients||[]){const key=clientKey(c);clients.set(key,{...(clients.get(key)||{}),...c});}
 const users=new Map<string,any>(seed.users.map((u:any)=>[u.u,{...u}]));
 for(const u of current.users||[])users.set(u.u,{...(users.get(u.u)||{}),...u});
 return {...structuredClone(seed),...current,clients:Array.from(clients.values()),users:Array.from(users.values())};
}
