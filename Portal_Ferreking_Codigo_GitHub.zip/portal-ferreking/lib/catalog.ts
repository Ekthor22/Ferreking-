import { env } from 'cloudflare:workers';
import seed from './seed-private.json';
import {seedRevision} from './seed-revision';
import {completePrivateData} from './merge-private';
export { identity } from './sessions';
export async function privateData(): Promise<any> {
 const object = await env.BUCKET!.get('private/catalog.json');
 const current=object ? await object.json() : null;
 if(object?.customMetadata?.seed_revision===seedRevision)return current;
 // Carga inicial y ampliación de cartera autorizada: conservar los cambios ya guardados.
 const data=completePrivateData(seed,current);
 const written=await env.BUCKET!.put('private/catalog.json',JSON.stringify(data),{
  httpMetadata:{contentType:'application/json'},customMetadata:{seed_revision:seedRevision},
  onlyIf:object?{etagMatches:object.etag}:{etagDoesNotMatch:'*'},
 });
 if(written===null){const latest=await env.BUCKET!.get('private/catalog.json');if(latest)return latest.json();throw new Error('No se pudo completar la carga privada.');}
 return data;
}
export function parseMaster(html: string) {
 const match = html.match(/<script\s+id="fk-data"\s+type="application\/json">([\s\S]*?)<\/script>/);
 if (!match) throw new Error('Selecciona el archivo maestro HTML de Ferreking.');
 const data = JSON.parse(match[1]);
 if (data.pub || !Array.isArray(data.clients) || !Array.isArray(data.users) || !Array.isArray(data.products)) throw new Error('Este archivo es la versión pública o no contiene la cartera y los usuarios.');
 if (data.users.some((u:any)=>typeof u.u!=='string'||!/^([a-f0-9]{64})$/.test(u.h||''))) throw new Error('El maestro tiene usuarios o PIN no válidos.');
 if (!data.users.some((u:any)=>u.r==='admin')) throw new Error('El maestro no tiene administrador.');
 for (const c of data.clients){if(c.dcto!=null && String(c.dcto).trim()!==''){const n=Number(String(c.dcto).trim().replace(/%$/,'').replace(',','.'));if(!Number.isFinite(n)||n<0||n>90)throw new Error('El maestro contiene un descuento de cliente inválido. Usa porcentajes entre 0 y 90.');}}
 data.sync = {url:'',key:''};
 return data;
}
export async function publicData(): Promise<any> {
 const response = await fetch('https://raw.githubusercontent.com/Ekthor22/Ferreking-/main/index.html', {cache:'no-store'});
 if (!response.ok) throw new Error('No se pudo recuperar el catálogo público. Intenta nuevamente.');
 const html = await response.text();
 const match = html.match(/<script\s+id="fk-data"\s+type="application\/json">([\s\S]*?)<\/script>/);
 if (!match) throw new Error('No se reconocen los datos del catálogo publicado.');
 return JSON.parse(match[1]);
}
export const privateHeaders = {'Cache-Control':'private, no-store, max-age=0', 'Vary':'Cookie', 'X-Content-Type-Options':'nosniff', 'Referrer-Policy':'same-origin'};
export function sameOrigin(request: Request) { return request.headers.get('origin') === new URL(request.url).origin; }
