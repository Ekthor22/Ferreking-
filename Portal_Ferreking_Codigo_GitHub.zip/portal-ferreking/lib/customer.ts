import {env} from 'cloudflare:workers';
import {digest} from './sessions';
import {privateData} from './catalog';
import {clientKey,discountPercent} from './access';
export const customerHeaders={'Cache-Control':'private, no-store, max-age=0','Referrer-Policy':'no-referrer','X-Content-Type-Options':'nosniff','X-Robots-Tag':'noindex, nofollow, noarchive'};
export async function customerForToken(token:string){
 if(!/^[a-f0-9]{64}$/.test(token))return null;
 const link=await env.DB!.prepare('SELECT client_key FROM client_links WHERE token_hash=? AND enabled=1').bind(await digest(token)).first<{client_key:string}>();
 if(!link)return null;
 const base=await privateData();const matches=base.clients.filter((c:any)=>clientKey(c)===link.client_key);
 if(matches.length!==1)return null;
 return {base,client:matches[0],discount:discountPercent(matches[0].dcto)};
}
export function customerData(base:any,pub:any,client:any){
 return {ver:pub.ver,verShow:pub.verShow,wa:base.wa,waPed:base.waPed,vend:'',valid:base.valid,trans:base.trans||[],co:base.co||{},products:pub.products,images:pub.images,clients:[],users:[],sync:{url:'',key:''},pub:true,offer:{client:{cod:client.cod||'',rut:client.rut||'',rs:client.rs||''},dcto:discountPercent(client.dcto)}};
}
