export const seedRevision='private-seed-local-v1';
