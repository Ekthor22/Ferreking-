export function normalize(value: string) { return (value || '').normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim().toLowerCase(); }
export function clientsForUser(clients: any[], seller: any) {
 if (!seller) return [];
 if (seller.r === 'admin' || seller.all === true) return clients;
 const name = normalize(seller.sv || seller.n);
 return clients.filter(c => c.own === seller.u || (c.vend && normalize(c.vend) === name));
}
export function clientKey(c:any){return c.cod?'C'+String(c.cod):String(c.rut||'').replace(/[^0-9kK]/g,'').toUpperCase()||normalize(c.rs);}
export function discountPercent(value:unknown){const n=Number(String(value==null?'':value).trim().replace(/%$/,'').replace(',','.'));return Number.isFinite(n)&&n>=0&&n<=90?Math.round(n*10)/10:0;}
