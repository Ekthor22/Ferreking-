import {cookies} from 'next/headers';
import {env} from 'cloudflare:workers';
import {privateData} from './catalog';
export async function digest(text:string){const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text));return Array.from(new Uint8Array(b),v=>v.toString(16).padStart(2,'0')).join('');}
export async function identity(){
 const token=(await cookies()).get('fk_session')?.value;
 if(!token||!/^[0-9a-f]{64}$/.test(token))return null;
 const row=await env.DB!.prepare('SELECT seller,pin_hash,expires FROM sessions WHERE token_hash=? AND expires>?').bind(await digest(token),Date.now()).first<{seller:string;pin_hash:string;expires:number}>();
 if(!row)return null;
 const data=await privateData();const seller=data.users.find((u:any)=>u.u===row.seller&&u.h===row.pin_hash);
 if(!seller)return null;
 return {userId:seller.u,displayName:seller.n,admin:seller.r==='admin',sellerCode:seller.u};
}
export function equal(a:string,b:string){if(a.length!==b.length)return false;let result=0;for(let i=0;i<a.length;i++)result|=a.charCodeAt(i)^b.charCodeAt(i);return result===0;}
