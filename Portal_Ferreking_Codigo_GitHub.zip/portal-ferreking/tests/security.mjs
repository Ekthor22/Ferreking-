import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {DatabaseSync} from 'node:sqlite';
import vm from 'node:vm';
import ts from 'typescript';
const db=new DatabaseSync(':memory:');
db.exec('CREATE TABLE sessions(token_hash TEXT PRIMARY KEY,seller TEXT,pin_hash TEXT,expires INTEGER);CREATE TABLE attempts(key TEXT PRIMARY KEY,count INTEGER,reset_at INTEGER);CREATE TABLE client_links(client_key TEXT PRIMARY KEY,token_hash TEXT UNIQUE,token TEXT,enabled INTEGER,created_at INTEGER);');
let cookie='';let currentPrice=10000;
const context=vm.createContext({crypto,TextEncoder,Response,Request,File,URL,Date,structuredClone,console,fetch:async()=>new Response('<script id="fk-data" type="application/json">'+JSON.stringify({ver:'2026-10-12',products:[{c:'SKU',p:currentPrice}],images:{}})+'</script>')});
const hash=async v=>Buffer.from(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(v))).toString('hex');
const data={ver:'2026-10-12',wa:'',waPed:'',valid:15,trans:[],co:{},sync:{url:'',key:''},users:[{u:'admin',n:'Admin',r:'admin',h:await hash('FK1:admin:123456')},{u:'uno',n:'Vendedor Uno',sv:'Cartera Uno',r:'vend',h:await hash('FK1:uno:456789')}],clients:[{cod:'01',rut:'11.111.111-1',rs:'CLIENTE_PROPIO',vend:'Cartera Uno',dcto:'15'},{cod:'02',rut:'22.222.222-2',rs:'CLIENTE_AJENO',vend:'Cartera Dos',dcto:'20'}]};
const adapter={prepare(sql){let params=[];const p={bind(...values){params=values;return p;},async first(){return db.prepare(sql).get(...params)||null;},async run(){return db.prepare(sql).run(...params);},async all(){return {results:db.prepare(sql).all(...params)};}};return p;},async batch(statements){return Promise.all(statements.map(s=>s.run()));}};
const env={DB:adapter,BUCKET:{get:async()=>null,put:async()=>{}}};
const cache=new Map();
function synthetic(key,values){if(cache.has(key))return cache.get(key);const m=new vm.SyntheticModule(Object.keys(values),function(){for(const[k,v]of Object.entries(values))this.setExport(k,v);},{context,identifier:key});cache.set(key,m);return m;}
function moduleAt(file){file=resolve(file);if(cache.has(file))return cache.get(file);if(file.endsWith('seed-private.json'))return synthetic(file,{default:data});const source=readFileSync(file,'utf8');const code=ts.transpile(source,{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022});const m=new vm.SourceTextModule(code,{context,identifier:file});cache.set(file,m);return m;}
function linker(spec,parent){if(spec==='cloudflare:workers')return synthetic(spec,{env});if(spec==='next/headers')return synthetic(spec,{cookies:async()=>({get:()=>cookie?{value:cookie}:undefined})});let f=resolve(dirname(parent.identifier),spec);if(!f.endsWith('.json'))f+='.ts';return moduleAt(f);}
const root=new vm.SourceTextModule("import * as login from './app/api/login/route';import * as catalog from './app/catalogo/route';import * as admin from './app/api/admin/route';import * as links from './app/api/client-links/route';import * as customer from './app/c/[token]/route';import * as manifest from './app/c/[token]/manifest.webmanifest/route';import {completePrivateData} from './lib/merge-private';export {login,catalog,admin,links,customer,manifest,completePrivateData};",{context,identifier:resolve('entry.ts')});
await root.link(linker);await root.evaluate();
const {login,catalog,admin,links,customer,manifest}=root.namespace;
const request=(path,body,origin='https://test.example')=>new Request('https://test.example'+path,{method:'POST',headers:{Origin:origin,'Content-Type':'application/json','cf-connecting-ip':'192.0.2.1'},body:JSON.stringify(body)});
assert.equal((await login.POST(request('/api/login',{username:'uno',pin:'456789'},'https://evil.example'))).status,403);
assert.equal((await login.POST(request('/api/login',{username:'uno',pin:'bad'}))).status,401);
const success=await login.POST(request('/api/login',{username:'uno',pin:'456789'}));assert.equal(success.status,200);
const setCookie=success.headers.get('set-cookie');assert.ok(setCookie.includes('HttpOnly')&&setCookie.includes('Secure')&&setCookie.includes('SameSite=Strict'));cookie=setCookie.match(/fk_session=([^;]+)/)[1];
const rendered=await catalog.GET(new Request('https://test.example/catalogo'));assert.equal(rendered.status,200);assert.equal(rendered.headers.get('Cache-Control'),'private, no-store, max-age=0');
const html=await rendered.text();const subset=JSON.parse(html.match(/<script id="fk-data" type="application\/json">([\s\S]*?)<\/script>/)[1]);assert.equal(subset.clients.length,1);assert.equal(subset.clients[0].rs,'CLIENTE_PROPIO');assert.equal(subset.users.length,1);assert.equal(subset.users[0].h,undefined);assert.ok(!html.includes('CLIENTE_AJENO'));assert.equal((await admin.POST(request('/api/admin',{}))).status,403);
assert.equal((await links.GET(new Request('https://test.example/api/client-links'))).status,403);
data.users[1].h=await hash('FK1:uno:999999');assert.equal((await catalog.GET(new Request('https://test.example/catalogo'))).status,302);cookie='';
for(let i=0;i<8;i++)await login.POST(request('/api/login',{username:'intruso',pin:'bad'}));assert.equal((await login.POST(request('/api/login',{username:'intruso',pin:'bad'}))).status,429);
console.log('Verificado: sesión segura, rechazo de origen externo, aislamiento de cartera, ausencia de PIN en HTML, bloqueo de vendedores en administración, revocación al cambiar PIN y límite de intentos.');

// Administración de enlaces y actualización sin cambiar URL.
const adminLogin=await login.POST(request('/api/login',{username:'admin',pin:'123456'}));assert.equal(adminLogin.status,200);cookie=adminLogin.headers.get('set-cookie').match(/fk_session=([^;]+)/)[1];
let created=await links.POST(request('/api/client-links',{action:'create',key:'C01'}));assert.equal(created.status,200);const {url}=await created.json();const token=url.split('/').pop();assert.ok(/^[a-f0-9]{64}$/.test(token));
created=await links.POST(request('/api/client-links',{action:'create',key:'C01'}));assert.equal((await created.json()).url,url);
const args={params:Promise.resolve({token})};cookie='';
let customerPage=await customer.GET(new Request(url),args);assert.equal(customerPage.status,200);assert.equal(customerPage.headers.get('referrer-policy'),'no-referrer');
let customerHtml=await customerPage.text();let customerJson=JSON.parse(customerHtml.match(/<script id="fk-data" type="application\/json">([\s\S]*?)<\/script>/)[1]);assert.equal(customerJson.offer.dcto,15);assert.equal(customerJson.offer.client.rs,'CLIENTE_PROPIO');assert.equal(customerJson.clients.length,0);assert.equal(customerJson.users.length,0);assert.ok(!customerHtml.includes('CLIENTE_AJENO'));assert.ok(!customerHtml.includes(data.users[0].h));
currentPrice=20000;data.clients[0].dcto='12.5';customerPage=await customer.GET(new Request(url),args);customerHtml=await customerPage.text();customerJson=JSON.parse(customerHtml.match(/<script id="fk-data" type="application\/json">([\s\S]*?)<\/script>/)[1]);assert.equal(customerJson.products[0].p,20000);assert.equal(customerJson.offer.dcto,12.5);
const install=await manifest.GET(new Request(url+'/manifest.webmanifest'),args);assert.equal(install.status,200);assert.equal((await install.json()).start_url,'/c/'+token);
assert.equal((await customer.GET(new Request(url),{params:Promise.resolve({token:'bad'})})).status,404);
cookie=adminLogin.headers.get('set-cookie').match(/fk_session=([^;]+)/)[1];assert.equal((await links.POST(request('/api/client-links',{action:'revoke',key:'C01'}))).status,200);cookie='';assert.equal((await customer.GET(new Request(url),args)).status,404);assert.equal((await manifest.GET(new Request(url+'/manifest.webmanifest'),args)).status,404);
console.log('Enlaces de clientes verificados: acceso restringido, enlace estable, descuento y precio actualizados, privacidad, instalación en su URL y revocación efectiva.');

const baseExample={clients:[{cod:'1',rs:'Uno',dcto:'0'},{cod:'2',rs:'Dos'}],users:[{u:'admin',h:'original'},{u:'nuevo',h:'nuevo'}],wa:'seed'};
const liveExample={clients:[{cod:'1',rs:'Uno actualizado',dcto:'18'},{cod:'3',rs:'Tres'}],users:[{u:'admin',h:'vigente'}],wa:'vigente'};
const merged=root.namespace.completePrivateData(baseExample,liveExample);
assert.equal(merged.clients.length,3);assert.equal(merged.clients.find(c=>c.cod==='1').dcto,'18');assert.equal(merged.clients.find(c=>c.cod==='1').rs,'Uno actualizado');assert.equal(merged.users.length,2);assert.equal(merged.users.find(u=>u.u==='admin').h,'vigente');assert.equal(merged.wa,'vigente');assert.equal(baseExample.clients[0].dcto,'0');
console.log('Carga completa verificada: clientes y usuarios faltantes añadidos, descuentos y cambios vigentes conservados.');
