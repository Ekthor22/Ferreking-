// Intentionally empty by default.
// Add Drizzle tables here when the site actually needs a database.
// See examples/d1/db/schema.ts for an opt-in example.
import { sqliteTable, text, integer } from 'drizzle-orm/sqlite-core';
export const members = sqliteTable('members', {
 email: text('email').primaryKey(),
 seller: text('seller').notNull(),
});
export const sessions=sqliteTable('sessions',{tokenHash:text('token_hash').primaryKey(),seller:text('seller').notNull(),pinHash:text('pin_hash').notNull(),expires:integer('expires').notNull()});
export const attempts=sqliteTable('attempts',{key:text('key').primaryKey(),count:integer('count').notNull(),resetAt:integer('reset_at').notNull()});
export const clientLinks=sqliteTable('client_links',{
 clientKey:text('client_key').primaryKey(),
 tokenHash:text('token_hash').notNull().unique(),
 token:text('token').notNull(),
 enabled:integer('enabled').notNull().default(1),
 createdAt:integer('created_at').notNull(),
});
