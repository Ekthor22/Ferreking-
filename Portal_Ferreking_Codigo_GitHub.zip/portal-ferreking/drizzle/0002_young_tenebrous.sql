CREATE TABLE `client_links` (
	`client_key` text PRIMARY KEY NOT NULL,
	`token_hash` text NOT NULL,
	`token` text NOT NULL,
	`enabled` integer DEFAULT 1 NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `client_links_token_hash_unique` ON `client_links` (`token_hash`);