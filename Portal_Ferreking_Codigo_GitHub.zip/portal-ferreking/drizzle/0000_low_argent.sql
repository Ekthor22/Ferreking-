CREATE TABLE `members` (
	`email` text PRIMARY KEY NOT NULL,
	`seller` text NOT NULL
);
